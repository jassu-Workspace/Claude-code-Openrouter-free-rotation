"""Neutral shared application core."""
